<!-- Homepage Template -->

@extends('plainlayout')

@section('gibjohndesc')

<?php
// Initialize the session
session_start();
?>

<div class="container-fluid px-4 text-center text-white p-5 col" style="padding-top: 300px;">

  <h4>Welcome to</h4>
  <h1>GibJohn Tutoring</h1>

  <div>
    <hr class="style1">
  </div>
  
  <p class="lead">Inspiring Education</p>
  <hr class="style1">
  <a class="btn btn-lg btn-light" href="index.php">Start learning!</a>

</div>

@endsection

@section('information')

<div class="container-fluid px-4 text-center text-white p-5 col" style="padding-top: 300px;">

  <h4>Welcome to</h4>
  <h1>GibJohn Tutoring</h1>

    <hr class="style1">

</div>

@endsection

<!-- Homepage Template -->