@extends('layouts.default')
    @section('content')
       home page
    @stop